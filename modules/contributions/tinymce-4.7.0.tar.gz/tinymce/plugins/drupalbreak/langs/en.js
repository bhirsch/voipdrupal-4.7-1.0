// UK lang variables

tinyMCE.addToLang('drupalbreak',{
title  : 'Insert Teaser Break',
desc   : 'Separate Drupal Teaser and Body'
});

tinyMCE.addToLang('drupalpagebreak',{
title  : 'Insert Page Break',
desc   : 'Separate Pages'
});
