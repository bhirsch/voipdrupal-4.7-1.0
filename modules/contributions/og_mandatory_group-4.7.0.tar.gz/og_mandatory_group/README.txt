
README for og_mandatory_group.module:

Compatible with Drupal 4.7.

An add-on for the Organic Groups module that makes one group mandatory for
all new users.

Choose one group that all new users will be put into. You can chose either
an open or a closed group. Any new user will be auto-approved as member of
the group.  The group manager(s) of groups that a new user joins will get
an automatic e-mail notice.

Requires the Organic Groups module.

---

originally written by Gerhard Killesreiter (killes)
4.7 version maintained by Peter (pwolanin@drupal)