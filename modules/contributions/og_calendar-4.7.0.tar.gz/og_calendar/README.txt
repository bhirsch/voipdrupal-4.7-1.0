$Id: README.txt,v 1.1.2.1 2006/05/12 15:24:08 webchick Exp $

DESCRIPTION
-----------
This module provides each group with a calendar showing only the group's
events.

REQUIREMENTS
------------
- Requires the organic groups module.
- Requires the event module.

INSTALLATION
------------
- Enable the module from administer >> modules.

USAGE
-----
- Click on the "group calendar" link from either the group details block
  or on the event node itself.

CREDITS
-------
Authored and maintained by Angela Byron of CivicSpace Labs
Support provided by Chad Philips
Sponsored by Raven Brooks of BuyBlue.org
