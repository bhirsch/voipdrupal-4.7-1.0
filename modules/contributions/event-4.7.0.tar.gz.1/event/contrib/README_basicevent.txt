basic event type with location support. 
